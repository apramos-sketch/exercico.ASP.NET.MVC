using Microsoft.AspNetCore.Mvc;

namespace MeuProjeto.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Boletim()
        {
            ViewBag.Disciplinas = new List<string>
            {
                "Matemática", "Português", "História", "Física"
            };

            ViewBag.Notas = new List<double>
            {
                9.5, 7.0, 5.5, 4.0
            };

            return View();
        }
    }
}

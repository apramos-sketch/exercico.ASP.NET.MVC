using Microsoft.AspNetCore.Mvc;

namespace MeuProjeto.Controllers
{
    public class ProdutoController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Produtos = new List<string>
            {
                "Notebook", "Mouse", "Teclado", "Monitor", "Headset"
            };

            ViewBag.Precos = new List<double>
            {
                3500, 80, 150, 900, 95
            };

            return View();
        }
    }
}
